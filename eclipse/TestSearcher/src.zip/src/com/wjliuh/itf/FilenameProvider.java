package com.wjliuh.itf;


public interface FilenameProvider {
	String getFilename();
}
