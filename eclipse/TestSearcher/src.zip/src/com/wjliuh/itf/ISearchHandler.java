package com.wjliuh.itf;

import java.awt.event.ActionEvent;

public interface ISearchHandler {

	public abstract void handlerEvent(ActionEvent e) throws Exception;
}
