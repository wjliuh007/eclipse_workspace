package com.wjliuh.result;

import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.TitledBorder;

import com.wjliuh.model.MyTableModel;
import com.wjliuh.model.Mytable;

public class ResultPanel extends JScrollPane {

	private static final long serialVersionUID = 4792873563460845575L;
	
	private JTable contentTable;
	
	private MyTableModel model;
	
	public ResultPanel(){
		contentTable = new Mytable();
		model = new MyTableModel();
		model.setTable(contentTable);
		this.setViewportView(contentTable);
        this.setBorder(BorderFactory.createTitledBorder(null,"搜索结果", TitledBorder.DEFAULT_JUSTIFICATION,
                TitledBorder.DEFAULT_POSITION, null, null));
	}

	public JTable getContentTable() {
		return contentTable;
	}

	public void setContentTable(JTable contentTable) {
		this.contentTable = contentTable;
	}

	public MyTableModel getModel() {
		return model;
	}

	public void setModel(MyTableModel model) {
		this.model = model;
	}
	
	
}
