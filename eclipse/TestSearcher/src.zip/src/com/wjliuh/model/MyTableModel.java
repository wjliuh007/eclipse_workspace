package com.wjliuh.model;

import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;


public class MyTableModel extends AbstractTableModel {

	private static final long serialVersionUID = 1969610268438153588L;
	
	JTable table;
	String[] colmnHeader = new String[]{"来源","过程","目的"};
	String[] colmnContent = new String[]{"src","produce","dest"};
	
	@Override
	public int getRowCount() {
		return 40;
	}
	
	@Override
	public String getColumnName(int col) {
		return colmnHeader[col];
	}

	@Override
	public int getColumnCount() {
		return colmnHeader.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Object obj = null;

		switch (columnIndex) {
		case 0:
			obj = String.valueOf("F:\\Android 4高级编程(第3版)(完整书签jb51.net).pdf");
			break;
		case 1:
			obj = String.valueOf("UIManager");
			break;
		case 2:
			obj = String.valueOf("setSyntaxEditingStyle");
			break;

		}
		return obj;
	}
	
	public boolean isCellEditable(int row, int col){
		getTable().getColumnModel().getColumn(0).setCellEditor(new MyCellEditor(new JComboBox()));
		return true;
	}

	public JTable getTable() {
		return table;
	}

	public void setTable(JTable table) {
		this.table = table;
	}
	

}
