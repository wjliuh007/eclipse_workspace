package com.wjliuh.model;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.FileNotFoundException;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.filechooser.FileSystemView;

import sun.awt.shell.ShellFolder;
import sun.swing.table.DefaultTableCellHeaderRenderer;
import wj.javax.swing.table.DefaultTableCellRenderer;

public class Mytable extends JTable implements MouseMotionListener{
	private int mouseOnRowIndex = -1;
	public Mytable() {
		this.addMouseMotionListener(this);
		
		this.setShowHorizontalLines(false);
		this.setShowVerticalLines(false);
		this.setIntercellSpacing(new Dimension(0, 0));

		this.setRowHeight(20);
		Font font = new Font(null, 0, 12);
		this.setFont(font);

		this.setDefaultRenderer(Object.class, new MyTableCellTitleRenderer());
		
	    // 设置table表头居中
	    DefaultTableCellHeaderRenderer thr = new DefaultTableCellHeaderRenderer();
	    thr.setHorizontalAlignment(JLabel.CENTER);
	    this.getTableHeader().setDefaultRenderer(thr);
	}

	public void initStyle() {
		// getColumnModel().getColumn(1).setCellEditor(new
		// DefaultCellEditor(jb));
	}

	public void setMouseOnRowIndex(int mouseOnRowIndex) {
		this.mouseOnRowIndex = mouseOnRowIndex;
	}
	
	@Override
	public void mouseMoved(MouseEvent e) {
		Mytable table = (Mytable) e.getComponent();
		Point point = e.getPoint();
		int rowAtPoint = table.rowAtPoint(point);
		System.out.println(rowAtPoint);
		table.setMouseOnRowIndex(rowAtPoint);
		table.updateUI();
	}
	
	class MyTableCellTitleRenderer extends DefaultTableCellRenderer {
		public Component getTableCellRendererComponent(JTable table,
				Object value, boolean isSelected, boolean hasFocus, int row,
				int column) {
			if (row == Mytable.this.mouseOnRowIndex) {
				setBackground(new Color(173, 216, 230));
			} else {
				setBackground(null);
			}
			// 根据特定的单元格设置不同的Renderer,假如你要在第2行第3列显示图标
			if (column == 0) {
				try {
					ShellFolder sf = ShellFolder.getShellFolder(new File("G:\\05.mp3"));
					
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Icon icon = FileSystemView.getFileSystemView().getSystemIcon(
						new File("G:\\05.mp3"));

				JLabel label = new JLabel("用户名：", icon, JLabel.LEFT);
				label.setOpaque(false);
				return label;
			}
			return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
		}
	}
	
	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}
}
