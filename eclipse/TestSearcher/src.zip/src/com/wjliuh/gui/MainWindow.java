package com.wjliuh.gui;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import com.wjliuh.enums.Img;
import com.wjliuh.menu.MenuBar;
import com.wjliuh.result.ResultPanel;
import com.wjliuh.searchbox.Searchbar;
import com.wjliuh.status.StatusBar;

/**
 * 主页面
 * @author JIE
 *
 */
public class MainWindow extends JFrame {

	private static final long serialVersionUID = 3742563814499366153L;
	
	/** 菜单区 */
	JMenuBar menuBar = new MenuBar();
	
	/** 搜索栏 */
	Searchbar searchPanel = new Searchbar();
	
	/** 搜索结果区 */
	ResultPanel resultPanel= new ResultPanel();
	
	/** 状态栏 */
	StatusBar statusPanel = new StatusBar();
	
	public MainWindow(){
		String appName = "ThunderSeacher";
		setTitle(appName);
		
		setIconImage(Img.TS_32.get());
		
		setJMenuBar(menuBar);
		
		add(searchPanel, BorderLayout.NORTH);

	    add(resultPanel, BorderLayout.CENTER);

		add(statusPanel,BorderLayout.SOUTH);
		
		searchPanel.setContentTable(resultPanel.getContentTable());
		searchPanel.setModel(resultPanel.getModel());
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.setSize(960, 600);
		this.setLocation(230, 60);
		
		
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				new MainWindow().setVisible(true);
			}
		});

	}

}


