package com.wjliuh.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JMenuItem;

import com.wjliuh.enums.Img;
import com.wjliuh.index.IndexConfigDialog;

public class CreateIndexMenuItem extends JMenuItem implements ActionListener{

	private static final long serialVersionUID = 1L;

	public CreateIndexMenuItem(){
		super("建索引");
		setIcon(new ImageIcon(Img.ADD.get()));
		addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		IndexConfigDialog dlg = new IndexConfigDialog();
		dlg.show();
		
	}

	
}
