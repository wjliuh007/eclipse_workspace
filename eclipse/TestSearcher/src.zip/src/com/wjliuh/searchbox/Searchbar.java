package com.wjliuh.searchbox;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JTable;

import com.wjliuh.itf.ISearchHandler;
import com.wjliuh.model.MyTableModel;

public class Searchbar extends JPanel implements ISearchHandler{

	private static final long serialVersionUID = 2262247891533198386L;
	
	JComboBox<String> scb;
	
	JButton button;
	
	private JTable contentTable;
	
	private MyTableModel model;
	
	public Searchbar(){
		
		this.setLayout(new BorderLayout());
		scb = getComboBox();
		button = getSearchBtn();	
		
		this.add(scb,BorderLayout.CENTER);
		this.add(button,BorderLayout.EAST);
	}
	
	private JButton getSearchBtn() {
		JButton btn = new JButton("搜索");
		btn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				contentTable.setModel(model);
				
			}
		});
		return btn;
	}

	private JComboBox<String> getComboBox(){
		SearchComBox<String> scb = new SearchComBox<String>(this);
		scb.addItem("");
		scb.addItem("adfasdf");
		scb.addItem("agbh");
		scb.addItem("234yhh");
		scb.setEditable(true);
		return scb;
	}

	public JTable getContentTable() {
		return contentTable;
	}

	public void setContentTable(JTable contentTable) {
		this.contentTable = contentTable;
	}

	public MyTableModel getModel() {
		return model;
	}

	public void setModel(MyTableModel model) {
		this.model = model;
	}

	@Override
	public void handlerEvent(ActionEvent e) throws Exception {
		if(contentTable==null || model ==null){
			return;
		}
		contentTable.setModel(model);
		
	}
	
	
}
