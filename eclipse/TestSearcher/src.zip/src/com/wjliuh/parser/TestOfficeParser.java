package com.wjliuh.parser;

import java.io.File;
import java.io.InputStream;

import org.apache.poi.hwpf.extractor.WordExtractor;

public class TestOfficeParser extends OfficeParser {

    @Override
    public String renderText(File file) throws Exception {
        return null;
    }

    /**
     * @param args
     */
    public static void main(String[] args) {

    }

    @Override
    public String renderText(InputStream is) throws Exception {
        WordExtractor extractor = null;
        try {
            extractor = new WordExtractor(is);
        }
        catch (Exception e) {
            // This can happen if the file has the "doc" extension, but is not a Word document
        }
        finally {
            is.close();
        }
        return extractor.getText();
    }

}
