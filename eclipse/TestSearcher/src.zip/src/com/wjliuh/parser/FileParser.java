package com.wjliuh.parser;

import java.io.File;


import com.wjliuh.utils.annotations.NotNull;

abstract class FileParser extends Parser {

	@NotNull
	protected abstract ParseResult parse(@NotNull File file,
			@NotNull ParseContext context) throws Exception;

	@NotNull
	protected String renderText(@NotNull File file, @NotNull String filename)
			throws Exception {
		ParseContext context = new ParseContext(filename);
		return parse(file, context).getContent().toString();
	}

}
