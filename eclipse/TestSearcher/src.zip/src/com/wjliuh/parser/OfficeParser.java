package com.wjliuh.parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.Index;
import org.apache.lucene.document.Field.Store;
import org.apache.poi.hpsf.PropertySetFactory;
import org.apache.poi.hpsf.SummaryInformation;

import com.wjliuh.utils.annotations.NotNull;

public abstract class OfficeParser {

    /**
     * Lucene field name for the absolute path of a <tt>Document</tt> file.
     */
    public static final String path = "path"; //$NON-NLS-1$

    /**
     * Lucene field name for the author of a <tt>Document</tt>.
     */
    public static final String author = "author"; //$NON-NLS-1$

    /**
     * Lucene field name for the title of a <tt>Document</tt>.
     */
    public static final String title = "title"; //$NON-NLS-1$

    /**
     * Lucene field name for the contents of a <tt>Document</tt>.
     */
    public static final String contents = "contents"; //$NON-NLS-1$

    /**
     * Lucene field name for the 'last modified' timestamp of the <tt>Document</tt> file.
     */
    public static final String lastModified = "lastModified"; //$NON-NLS-1$

    public static final String parsedBy = "parsedBy"; //$NON-NLS-1$

    @NotNull
    public Document parse(@NotNull File file) throws Exception {
        InputStream in = new FileInputStream(file);
        String cntents = this.renderText(in);
        String title = file.getName();// TODO 用POI获取文件的标题
//        SummaryInformation si = (SummaryInformation) PropertySetFactory.create(in);
        Document luceneDoc = new org.apache.lucene.document.Document();
        luceneDoc.add(new Field(OfficeParser.lastModified, String.valueOf(file.lastModified()), Store.YES, Index.NO));
        luceneDoc.add(new Field(OfficeParser.title, title, Store.YES, Index.ANALYZED));
        luceneDoc.add(new Field(OfficeParser.author, "", Store.YES, Index.NO));
        luceneDoc.add(new Field(OfficeParser.contents, cntents, Store.NO, Index.ANALYZED));
        luceneDoc.add(new Field(path,file.getAbsolutePath(),Store.YES,Index.NO));
        return luceneDoc;

    }

    public abstract String renderText(InputStream is) throws Exception;

    public abstract String renderText(File file) throws Exception;

}
