package com.wjliuh.parser;

import java.util.Collection;

import com.wjliuh.utils.annotations.NotNull;

public abstract class Parser {
	
	Parser() {} 

	@NotNull
	protected abstract Collection<String> getExtensions();
	
	@NotNull
	protected abstract Collection<String> getTypes();
	
	@NotNull
	public abstract String getTypeLabel();

}
