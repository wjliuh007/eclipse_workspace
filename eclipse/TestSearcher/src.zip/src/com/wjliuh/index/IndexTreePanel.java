package com.wjliuh.index;

import javax.swing.JScrollPane;

public class IndexTreePanel extends JScrollPane {
	public IndexTreePanel() {
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
