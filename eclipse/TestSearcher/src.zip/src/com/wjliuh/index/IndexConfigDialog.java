package com.wjliuh.index;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.filechooser.FileSystemView;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriter.MaxFieldLength;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

import com.wjliuh.parser.TestOfficeParser;

public class IndexConfigDialog<T, V> extends JDialog {
	private JTextField textField;
	private JTextField textField_1;
	private static JTextArea precessArea = new JTextArea();
	private long start = 0L;
	private String filePath=null;
	public IndexConfigDialog() {
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel(new BorderLayout());
		getContentPane().add(panel, BorderLayout.NORTH);
		
		textField = new JTextField();
		panel.add(textField,BorderLayout.CENTER);
		textField.setColumns(50);
		
		JButton btnNewButton = new JButton("...");
		panel.add(btnNewButton,BorderLayout.EAST);
		panel.setBorder(BorderFactory.createTitledBorder("目标路径"));
		
		JPanel panel_1 = new JPanel();
		getContentPane().add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_2 = new JPanel(new BorderLayout());
		panel_1.add(panel_2, BorderLayout.NORTH);
		panel_2.setBorder(BorderFactory.createTitledBorder("过滤规则"));
		
		JLabel lblNewLabel = new JLabel("文件类型:");
		panel_2.add(lblNewLabel,BorderLayout.WEST);
		
		textField_1 = new JTextField();
		panel_2.add(textField_1,BorderLayout.CENTER);
		textField_1.setColumns(30);
		
		JPanel panel_3 = new JPanel();
		panel_1.add(panel_3, BorderLayout.CENTER);
		panel_3.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_4 = new JPanel(new BorderLayout());
		panel_3.add(panel_4, BorderLayout.NORTH);
		
		JButton btnNewButton_1 = new JButton("开始");
		panel_4.add(btnNewButton_1,BorderLayout.EAST);
		panel_4.setBorder(BorderFactory.createTitledBorder(""));
		
		//-------------
		btnNewButton_1.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				filePath = textField.getText();
				AppendWorker worker = new AppendWorker();
				worker.execute();
				start = System.currentTimeMillis();
				
				
			}});
		//-------------

//		precessArea.setLineWrap(true);
		precessArea.setMargin(new Insets(0, 5, 0, 0));
		precessArea.setFont(new Font("",precessArea.getFont().getStyle(),13));
		JScrollPane scroll = new JScrollPane(precessArea);
		//分别设置水平和垂直滚动条自动出现 
		scroll.setHorizontalScrollBarPolicy( 
		JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED); 
		scroll.setVerticalScrollBarPolicy( 
		JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED); 
//
//		//分别设置水平和垂直滚动条总是出现 
//		scroll.setHorizontalScrollBarPolicy( 
//		JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS); 
//		scroll.setVerticalScrollBarPolicy( 
//		JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); 
//
//		//分别设置水平和垂直滚动条总是隐藏
//		scroll.setHorizontalScrollBarPolicy( 
//		JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); 
//		scroll.setVerticalScrollBarPolicy( 
//		JScrollPane.VERTICAL_SCROLLBAR_NEVER); 
		panel_3.add(scroll, BorderLayout.CENTER);
		scroll.setBorder(BorderFactory.createTitledBorder("进度"));
		
		this.setSize(447, 470);
		addWindowListener(new WindowAdapter() {
		      public void windowClosing(WindowEvent evt) {
		    	  IndexConfigDialog.this.dispose();
		      }
		});

	}
    
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				new IndexConfigDialog().setVisible(true);
			}
		});
	}
	
	/** The Lucene Analyzer used. */
	public static final Analyzer analyzer = new StandardAnalyzer(Version.LUCENE_30);

	private transient IndexWriter writer;
	
	/** The Lucene IndexReader used. */
	private transient IndexReader reader;

	TestOfficeParser parser = new TestOfficeParser();
	
	class AppendWorker extends SwingWorker<List<String>,String>{

		@Override
		protected List<String> doInBackground() throws Exception {
			File[] dicks = FileSystemView.getFileSystemView().getFiles(new File(filePath), true);

			Directory directory = FSDirectory.open(new File("G:/licene/first"));
			writer = new IndexWriter(directory, analyzer, MaxFieldLength.UNLIMITED);
			
	        for (int i = 0; i < dicks.length; i++) {
	            File file = dicks[i];
	            createIndex(file);
	        }
			
			
			
			
			
			
			
			
			return null;
		}
		
		protected void process(List<String> msgs){
	        for(String info: msgs) {
	            if (isCancelled()) {
	                break;
	            }
	            precessArea.append(info);
	        }
		}
		
	    @Override
	    protected void done() {

	        setProgress(100);
	        if (isCancelled()) {
	            return;
	        }
	        precessArea.append("任务结束\n");
	        long end = System.currentTimeMillis();
	        int second = (int) ((end - start)/1000);
	        
	        int minute = second/60;
	        second = second%60;
	        String msg = String.format("%s%d%s%d%s", "共耗时：",minute,"分",second,"秒\n");
	        precessArea.append(msg);
	        try {
				writer.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
	        IndexConfigDialog.this.dispose();
	    }
	      
		private void createIndex(File file) {
	        if (file.isDirectory()) {
	            File[] fs = file.listFiles();
	            for (int i = 0; i < fs.length; i++) {
	            	listFiles(fs[i]);
	            }
	        }
	        else {
	        	try {
	        		writer.addDocument(parser.parse(file));
				} catch (Exception e) {
					e.printStackTrace();
				}
	        	publish(file.getName()+"\n");
	        }
			
		}
		
	    /**
	     * 递归
	     * 
	     * @param file
	     */
	    private void listFiles(File file) {
	        if (file.isDirectory()) {
	            File[] fs = file.listFiles();
	            for (int i = 0; i < fs.length; i++) {
	            	listFiles(fs[i]);
	            }
	        }
	        else {
//	        	msgs.add(file.getName()+"\n");
	        	publish(file.getName()+"\n");
	        }

	    }
		
	}

}
